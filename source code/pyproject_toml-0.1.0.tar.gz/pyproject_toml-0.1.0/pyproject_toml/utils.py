def to_hyphen(field: str):
    return field.replace("_", "-")
